import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ClientStrip } from './components/ClientStrip';
import { Services } from './components/Services';
import { Portfolio } from './components/Portfolio';
import { Pricing } from './components/Pricing';
import { Team } from './components/Team';
import { Contact } from './components/Contact';
import { EnquiryModal } from './components/EnquiryModal';
import { ReelPlayerModal } from './components/ReelPlayerModal';
import { PortfolioItem } from './types';

export default function App() {
  const [enquiryModalOpen, setEnquiryModalOpen] = useState(false);
  const [selectedReel, setSelectedReel] = useState<PortfolioItem | null>(null);

  return (
    <div className="min-h-screen bg-[#F7F4EC] text-[#1B1712] font-sans-editorial selection:bg-[#96662C]/20 selection:text-[#1B1712]">
      {/* Sticky Minimal Navigation matching Stitch */}
      <Navbar onOpenEnquiry={() => setEnquiryModalOpen(true)} />

      {/* Main Content Sections */}
      <main>
        {/* Hero with Curtain/Mask Wipe Reveal */}
        <Hero onOpenEnquiry={() => setEnquiryModalOpen(true)} />

        {/* Continuous Horizontal Client Name Marquee Strip */}
        <ClientStrip />

        {/* Numbered Editorial Services Index (01 to 04) */}
        <Services />

        {/* Selected Portfolio Rows (Displaying Only Client/Shop Names) */}
        <Portfolio onSelectReel={(item) => setSelectedReel(item)} />

        {/* Typographic Pricing Table with WhatsApp Handoff */}
        <Pricing />

        {/* Simple Editorial Team Line */}
        <Team />

        {/* Strong Closing Contact Section */}
        <Contact onOpenEnquiry={() => setEnquiryModalOpen(true)} />
      </main>

      {/* Interactive Enquiry Modal (Direct WhatsApp + Minimal Form) */}
      <EnquiryModal
        isOpen={enquiryModalOpen}
        onClose={() => setEnquiryModalOpen(false)}
      />

      {/* 9:16 Video Reel Viewer Modal */}
      <ReelPlayerModal
        item={selectedReel}
        onClose={() => setSelectedReel(null)}
      />
    </div>
  );
}
