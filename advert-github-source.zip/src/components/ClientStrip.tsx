import React from 'react';
import { CLIENT_NAMES } from '../data';

export const ClientStrip: React.FC = () => {
  // Duplicate the list 3 times to ensure a continuous, seamless infinite loop across all viewport widths
  const marqueeItems = [...CLIENT_NAMES, ...CLIENT_NAMES, ...CLIENT_NAMES];

  return (
    <section
      id="client-strip-section"
      aria-label="Clients and Showrooms"
      className="relative py-7 md:py-9 border-b border-[#1B1712]/10 overflow-hidden bg-[#F7F4EC] select-none"
    >
      {/* Editorial side fades for seamless entry/exit */}
      <div className="pointer-events-none absolute left-0 top-0 bottom-0 w-12 md:w-28 bg-gradient-to-r from-[#F7F4EC] to-transparent z-10" />
      <div className="pointer-events-none absolute right-0 top-0 bottom-0 w-12 md:w-28 bg-gradient-to-l from-[#F7F4EC] to-transparent z-10" />

      {/* Marquee track */}
      <div className="animate-marquee flex items-center">
        {marqueeItems.map((client, index) => (
          <div
            key={`${client.id}-${index}`}
            className="flex items-center shrink-0 pr-8 md:pr-12"
          >
            <span className="font-serif-editorial italic text-lg sm:text-xl md:text-2xl text-[#1B1712]/85 tracking-normal whitespace-nowrap transition-colors duration-200 hover:text-[#96662C] cursor-default">
              {client.name}
            </span>
            <span
              className="inline-block w-1.5 h-1.5 rounded-full bg-[#96662C] ml-8 md:ml-12 opacity-80 shrink-0"
              aria-hidden="true"
            />
          </div>
        ))}
      </div>
    </section>
  );
};
