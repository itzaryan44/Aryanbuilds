import React, { useState, useEffect } from 'react';
import { STUDIO_INFO, PRICING_PLANS } from '../data';
import { EnquiryData } from '../types';

interface EnquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EnquiryModal: React.FC<EnquiryModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'whatsapp' | 'form'>('whatsapp');
  const [formData, setFormData] = useState<EnquiryData>({
    name: '',
    shopName: '',
    phone: '',
    requirement: 'Free Trial — ₹499 (2 Videos)',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  // Close modal on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Prevent background body scrolling when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
      setSubmitted(false);
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const generateWhatsAppFromForm = () => {
    const text = `*New Studio Enquiry*\n\n*Name:* ${formData.name}\n*Shop / Business:* ${formData.shopName}\n*Phone:* ${formData.phone}\n*Requirement:* ${formData.requirement}\n*Message:* ${formData.message || 'None'}`;
    return `https://wa.me/${STUDIO_INFO.whatsappRaw}?text=${encodeURIComponent(text)}`;
  };

  return (
    <div
      id="enquiry-modal-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="enquiry-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#1B1712]/60 backdrop-blur-sm animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="enquiry-modal-container"
        className="relative w-full max-w-xl bg-[#F7F4EC] border border-[#1B1712]/15 shadow-2xl p-6 sm:p-10 max-h-[90vh] overflow-y-auto"
      >
        {/* Close Button */}
        <button
          type="button"
          id="close-enquiry-modal-btn"
          onClick={onClose}
          aria-label="Close enquiry modal"
          className="absolute top-6 right-6 text-2xl text-[#1B1712]/60 hover:text-[#1B1712] transition-colors focus:outline-none"
        >
          ✕
        </button>

        {/* Modal Header */}
        <div className="mb-8">
          <span className="text-[11px] uppercase tracking-[0.22em] text-[#96662C] font-sans-editorial font-medium block mb-2">
            Advert Studio • Giridih
          </span>
          <h3
            id="enquiry-modal-title"
            className="font-serif-editorial italic text-3xl sm:text-4xl text-[#1B1712] font-normal tracking-tight"
          >
            Studio Enquiry
          </h3>
          <p className="text-xs sm:text-sm text-[#1B1712]/70 font-sans-editorial mt-2">
            Connect immediately on WhatsApp or submit your shop&apos;s requirements below.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-[#1B1712]/10 mb-8 text-xs uppercase tracking-[0.18em] font-medium font-sans-editorial">
          <button
            type="button"
            id="tab-whatsapp-btn"
            onClick={() => setActiveTab('whatsapp')}
            className={`pb-3 mr-8 transition-colors border-b-2 ${
              activeTab === 'whatsapp'
                ? 'border-[#96662C] text-[#96662C]'
                : 'border-transparent text-[#1B1712]/50 hover:text-[#1B1712]'
            }`}
          >
            1. Direct WhatsApp
          </button>
          <button
            type="button"
            id="tab-form-btn"
            onClick={() => setActiveTab('form')}
            className={`pb-3 transition-colors border-b-2 ${
              activeTab === 'form'
                ? 'border-[#96662C] text-[#96662C]'
                : 'border-transparent text-[#1B1712]/50 hover:text-[#1B1712]'
            }`}
          >
            2. Enquiry Form
          </button>
        </div>

        {/* TAB 1: Direct WhatsApp Action */}
        {activeTab === 'whatsapp' && (
          <div className="space-y-6">
            <div className="p-6 bg-[#1B1712]/[0.03] border border-[#1B1712]/10">
              <span className="text-[11px] uppercase tracking-[0.2em] text-[#96662C] font-medium block mb-1">
                Official Studio WhatsApp
              </span>
              <div className="font-serif-editorial italic text-3xl text-[#1B1712] mb-3">
                {STUDIO_INFO.whatsappNumber}
              </div>
              <p className="text-sm text-[#1B1712]/70 font-sans-editorial leading-relaxed">
                Connect directly with the Advert studio team for fast project scheduling, slot availability, or custom video production queries.
              </p>
            </div>

            <div className="flex flex-col gap-3">
              <a
                href={`https://wa.me/${STUDIO_INFO.whatsappRaw}?text=${encodeURIComponent('Hello Advert Studio, I would like to enquire about video production for my shop.')}`}
                target="_blank"
                rel="noopener noreferrer"
                id="modal-direct-whatsapp-btn"
                className="w-full text-center py-3.5 border border-[#96662C] bg-[#96662C] text-[#F7F4EC] hover:bg-[#805523] transition-colors text-xs uppercase tracking-[0.2em] font-medium block"
              >
                Open WhatsApp Chat Now ↗
              </a>

              <button
                type="button"
                onClick={() => setActiveTab('form')}
                className="w-full text-center py-2.5 text-xs text-[#1B1712]/60 hover:text-[#1B1712] uppercase tracking-[0.16em] font-sans-editorial"
              >
                Or fill out the enquiry form instead ↓
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: Minimal Enquiry Form */}
        {activeTab === 'form' && !submitted && (
          <form onSubmit={handleSubmit} id="studio-enquiry-form" className="space-y-5">
            <div>
              <label
                htmlFor="enquiry-name"
                className="block text-xs uppercase tracking-[0.18em] text-[#1B1712]/70 font-sans-editorial mb-1.5"
              >
                Your Name *
              </label>
              <input
                type="text"
                id="enquiry-name"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. Rahul Sharma"
                className="w-full px-4 py-2.5 bg-transparent border border-[#1B1712]/20 text-[#1B1712] text-sm font-sans-editorial focus:outline-none focus:border-[#96662C] rounded-none"
              />
            </div>

            <div>
              <label
                htmlFor="enquiry-shop"
                className="block text-xs uppercase tracking-[0.18em] text-[#1B1712]/70 font-sans-editorial mb-1.5"
              >
                Shop / Business Name *
              </label>
              <input
                type="text"
                id="enquiry-shop"
                required
                value={formData.shopName}
                onChange={(e) => setFormData({ ...formData, shopName: e.target.value })}
                placeholder="e.g. Sharma Furniture & Electronics"
                className="w-full px-4 py-2.5 bg-transparent border border-[#1B1712]/20 text-[#1B1712] text-sm font-sans-editorial focus:outline-none focus:border-[#96662C] rounded-none"
              />
            </div>

            <div>
              <label
                htmlFor="enquiry-phone"
                className="block text-xs uppercase tracking-[0.18em] text-[#1B1712]/70 font-sans-editorial mb-1.5"
              >
                Phone Number *
              </label>
              <input
                type="tel"
                id="enquiry-phone"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="e.g. +91 9876543210"
                className="w-full px-4 py-2.5 bg-transparent border border-[#1B1712]/20 text-[#1B1712] text-sm font-sans-editorial focus:outline-none focus:border-[#96662C] rounded-none"
              />
            </div>

            <div>
              <label
                htmlFor="enquiry-requirement"
                className="block text-xs uppercase tracking-[0.18em] text-[#1B1712]/70 font-sans-editorial mb-1.5"
              >
                Requirement *
              </label>
              <select
                id="enquiry-requirement"
                value={formData.requirement}
                onChange={(e) => setFormData({ ...formData, requirement: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#F7F4EC] border border-[#1B1712]/20 text-[#1B1712] text-sm font-sans-editorial focus:outline-none focus:border-[#96662C] rounded-none"
              >
                {PRICING_PLANS.map((plan) => (
                  <option key={plan.id} value={`${plan.name} — ${plan.price}`}>
                    {plan.name} — {plan.price} ({plan.deliverables})
                  </option>
                ))}
                <option value="Jingles & Voiceovers">Jingles & Voiceovers</option>
                <option value="Showroom Launch & Event Coverage">Showroom Launch & Event Coverage</option>
                <option value="Custom Video Advertising Project">Custom Video Advertising Project</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="enquiry-message"
                className="block text-xs uppercase tracking-[0.18em] text-[#1B1712]/70 font-sans-editorial mb-1.5"
              >
                Message
              </label>
              <textarea
                id="enquiry-message"
                rows={3}
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="Tell us about your upcoming promotion, sale dates, or preferred shooting date..."
                className="w-full px-4 py-2.5 bg-transparent border border-[#1B1712]/20 text-[#1B1712] text-sm font-sans-editorial focus:outline-none focus:border-[#96662C] rounded-none resize-none"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                id="submit-enquiry-form-btn"
                className="w-full py-3.5 border border-[#96662C] bg-[#96662C] text-[#F7F4EC] hover:bg-[#805523] transition-colors text-xs uppercase tracking-[0.2em] font-medium"
              >
                Submit Enquiry
              </button>
            </div>
          </form>
        )}

        {/* Confirmation Screen after Form Submit */}
        {activeTab === 'form' && submitted && (
          <div className="py-6 space-y-6 animate-fadeIn">
            <div className="p-6 bg-[#1B1712]/[0.03] border border-[#1B1712]/15 space-y-3">
              <span className="text-[11px] uppercase tracking-[0.2em] text-[#96662C] font-medium block">
                Enquiry Recorded
              </span>
              <h4 className="font-serif-editorial italic text-2xl text-[#1B1712]">
                Thank you, {formData.name}.
              </h4>
              <p className="text-sm text-[#1B1712]/75 font-sans-editorial">
                We have received your enquiry for <strong className="text-[#1B1712]">{formData.shopName}</strong> ({formData.requirement}).
              </p>
            </div>

            <div className="space-y-3">
              <p className="text-xs text-[#1B1712]/70 font-sans-editorial">
                Send this brief directly to our production team on WhatsApp for instant confirmation:
              </p>
              <a
                href={generateWhatsAppFromForm()}
                target="_blank"
                rel="noopener noreferrer"
                id="forward-whatsapp-btn"
                className="w-full text-center py-3.5 border border-[#96662C] bg-[#96662C] text-[#F7F4EC] hover:bg-[#805523] transition-colors text-xs uppercase tracking-[0.2em] font-medium block"
              >
                Forward Brief to WhatsApp (+91 6207255900) ↗
              </a>
              <button
                type="button"
                onClick={onClose}
                className="w-full text-center py-2.5 text-xs text-[#1B1712]/60 hover:text-[#1B1712] uppercase tracking-[0.16em]"
              >
                Close Window
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
