import React, { useState } from 'react';
import { STUDIO_INFO } from '../data';

interface NavbarProps {
  onOpenEnquiry: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenEnquiry }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header
      id="main-navigation"
      className="sticky top-0 z-40 w-full bg-[#F7F4EC]/90 backdrop-blur-md border-b border-[#1B1712]/10 transition-colors duration-200"
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 h-20 flex items-center justify-between">
        {/* Advert Wordmark */}
        <a
          href="#"
          id="nav-logo"
          className="group flex items-baseline gap-1.5 text-[#1B1712] focus:outline-none"
        >
          <span className="font-serif-editorial text-2xl md:text-3xl italic tracking-tight font-normal">
            {STUDIO_INFO.brand}
          </span>
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#96662C]" />
          <span className="hidden sm:inline-block ml-2 text-[11px] uppercase tracking-[0.2em] text-[#1B1712]/60 font-sans-editorial font-medium">
            Studio
          </span>
        </a>

        {/* Desktop Navigation Links */}
        <nav
          id="desktop-nav"
          aria-label="Main Navigation"
          className="hidden md:flex items-center gap-8 text-[13px] uppercase tracking-[0.16em] text-[#1B1712]/75 font-medium font-sans-editorial"
        >
          <a
            href="#services"
            id="nav-link-services"
            className="hover:text-[#96662C] transition-colors py-2 focus:outline-none focus:text-[#96662C]"
          >
            What we make
          </a>
          <a
            href="#work"
            id="nav-link-work"
            className="hover:text-[#96662C] transition-colors py-2 focus:outline-none focus:text-[#96662C]"
          >
            Work
          </a>
          <a
            href="#pricing"
            id="nav-link-pricing"
            className="hover:text-[#96662C] transition-colors py-2 focus:outline-none focus:text-[#96662C]"
          >
            Pricing
          </a>
          <a
            href="#contact"
            id="nav-link-contact"
            className="hover:text-[#96662C] transition-colors py-2 focus:outline-none focus:text-[#96662C]"
          >
            Contact
          </a>

          {/* Outlined "Enquire" Button */}
          <button
            type="button"
            id="nav-enquire-btn"
            onClick={onOpenEnquiry}
            className="ml-2 px-5 py-2.5 border border-[#96662C] text-[#96662C] hover:bg-[#96662C] hover:text-[#F7F4EC] transition-all duration-200 text-[12px] uppercase tracking-[0.18em] font-medium rounded-none focus:outline-none focus:ring-1 focus:ring-[#96662C]"
          >
            Enquire
          </button>
        </nav>

        {/* Mobile Hamburger Button */}
        <div className="flex items-center gap-3 md:hidden">
          <button
            type="button"
            id="mobile-enquire-quick-btn"
            onClick={onOpenEnquiry}
            className="px-3.5 py-1.5 border border-[#96662C] text-[#96662C] text-[11px] uppercase tracking-[0.15em] font-medium focus:outline-none"
          >
            Enquire
          </button>
          <button
            type="button"
            id="mobile-menu-toggle-btn"
            aria-label="Toggle navigation menu"
            aria-expanded={mobileMenuOpen}
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#1B1712] focus:outline-none"
          >
            <div className="w-5 h-4 flex flex-col justify-between">
              <span
                className={`h-[1.5px] bg-[#1B1712] w-full transition-transform duration-200 origin-left ${
                  mobileMenuOpen ? 'rotate-45 translate-x-0.5' : ''
                }`}
              />
              <span
                className={`h-[1.5px] bg-[#1B1712] w-full transition-opacity duration-200 ${
                  mobileMenuOpen ? 'opacity-0' : 'opacity-100'
                }`}
              />
              <span
                className={`h-[1.5px] bg-[#1B1712] w-full transition-transform duration-200 origin-left ${
                  mobileMenuOpen ? '-rotate-45 translate-x-0.5' : ''
                }`}
              />
            </div>
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div
          id="mobile-menu-drawer"
          className="md:hidden border-b border-[#1B1712]/10 bg-[#F7F4EC] px-6 py-8 animate-fadeIn"
        >
          <nav className="flex flex-col gap-5 text-sm uppercase tracking-[0.18em] font-sans-editorial text-[#1B1712]/80">
            <a
              href="#services"
              id="mobile-nav-services"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1 hover:text-[#96662C] transition-colors"
            >
              What we make
            </a>
            <a
              href="#work"
              id="mobile-nav-work"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1 hover:text-[#96662C] transition-colors"
            >
              Work
            </a>
            <a
              href="#pricing"
              id="mobile-nav-pricing"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1 hover:text-[#96662C] transition-colors"
            >
              Pricing
            </a>
            <a
              href="#contact"
              id="mobile-nav-contact"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1 hover:text-[#96662C] transition-colors"
            >
              Contact
            </a>
            <div className="pt-4 border-t border-[#1B1712]/10 flex flex-col gap-3">
              <button
                type="button"
                id="mobile-drawer-enquire-btn"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenEnquiry();
                }}
                className="w-full text-center py-3 border border-[#96662C] text-[#96662C] text-xs uppercase tracking-[0.2em] font-medium"
              >
                Send Studio Enquiry
              </button>
              <a
                href={`https://wa.me/${STUDIO_INFO.whatsappRaw}`}
                target="_blank"
                rel="noopener noreferrer"
                id="mobile-drawer-whatsapp-btn"
                className="w-full text-center py-2.5 text-xs text-[#1B1712]/70 lowercase tracking-wider font-sans-editorial hover:text-[#96662C]"
              >
                Chat on WhatsApp (+91 6207255900)
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
