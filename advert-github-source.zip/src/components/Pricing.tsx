import React, { useEffect, useRef, useState } from 'react';
import { PRICING_PLANS, STUDIO_INFO } from '../data';

export const Pricing: React.FC = () => {
  const headingRef = useRef<HTMLDivElement>(null);
  const [ruleVisible, setRuleVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRuleVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (headingRef.current) {
      observer.observe(headingRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const getWhatsAppUrl = (message: string) => {
    return `https://wa.me/${STUDIO_INFO.whatsappRaw}?text=${encodeURIComponent(message)}`;
  };

  return (
    <section
      id="pricing"
      className="py-20 md:py-32 px-6 md:px-12 max-w-7xl mx-auto border-b border-[#1B1712]/10"
    >
      {/* Section Header */}
      <div ref={headingRef} className="max-w-3xl mb-16 md:mb-24">
        <span className="text-[12px] uppercase tracking-[0.22em] text-[#96662C] font-sans-editorial font-medium block mb-3">
          Investment & Plans
        </span>
        <h2
          id="pricing-heading"
          className="font-serif-editorial italic text-3xl sm:text-4xl md:text-5xl text-[#1B1712] font-normal tracking-tight"
        >
          Studio pricing
        </h2>

        {/* Thin antique-brass rule that draws itself */}
        <div className="relative h-[1px] w-full bg-[#1B1712]/10 mt-6 overflow-hidden">
          <div
            className={`absolute left-0 top-0 bottom-0 bg-[#96662C] transition-all duration-1000 ease-out ${
              ruleVisible ? 'w-32 md:w-48' : 'w-0'
            }`}
          />
        </div>
      </div>

      {/* Clean Typographic Pricing Table (No SaaS cards, no shadows, no colored boxes) */}
      <div className="w-full border-t border-[#1B1712]/10 divide-y divide-[#1B1712]/10">
        {PRICING_PLANS.map((plan) => (
          <a
            key={plan.id}
            href={getWhatsAppUrl(plan.whatsappMessage)}
            target="_blank"
            rel="noopener noreferrer"
            id={`pricing-row-${plan.id}`}
            className="group py-8 sm:py-10 md:py-12 grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8 items-baseline transition-colors duration-200 hover:bg-[#1B1712]/[0.02] px-2 sm:px-4 cursor-pointer block"
            title={`Enquire about ${plan.name} on WhatsApp`}
          >
            {/* Plan Name & Tag */}
            <div className="md:col-span-5 flex flex-wrap items-baseline gap-3">
              <span className="font-serif-editorial italic text-2xl sm:text-3xl text-[#1B1712] group-hover:text-[#96662C] transition-colors">
                {plan.name}
              </span>
              {plan.isMostRequested && (
                <span className="font-serif-editorial italic text-sm md:text-base text-[#96662C] tracking-wide">
                  most requested
                </span>
              )}
            </div>

            {/* Deliverables / Details (From User Prompt) */}
            <div className="md:col-span-4">
              <span className="text-sm sm:text-base text-[#1B1712]/70 font-sans-editorial font-normal">
                {plan.deliverables}
              </span>
            </div>

            {/* Price & Direct WhatsApp Action */}
            <div className="md:col-span-3 flex items-baseline justify-between md:justify-end gap-6">
              <span className="font-serif-editorial text-2xl sm:text-3xl text-[#1B1712] font-normal">
                {plan.price}
              </span>
              <span className="text-xs uppercase tracking-[0.18em] text-[#96662C] font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-200 hidden sm:inline-block">
                Enquire ↗
              </span>
            </div>
          </a>
        ))}
      </div>

      {/* Note under pricing */}
      <div className="mt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs font-sans-editorial text-[#1B1712]/50 tracking-wider">
        <span>Click any plan to connect directly on WhatsApp with pre-filled details</span>
        <span>Studio WhatsApp: {STUDIO_INFO.whatsappNumber}</span>
      </div>
    </section>
  );
};
