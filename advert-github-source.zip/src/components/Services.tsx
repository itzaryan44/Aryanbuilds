import React, { useEffect, useRef, useState } from 'react';
import { SERVICES } from '../data';

export const Services: React.FC = () => {
  const headingRef = useRef<HTMLDivElement>(null);
  const [ruleVisible, setRuleVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRuleVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (headingRef.current) {
      observer.observe(headingRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="services"
      className="py-20 md:py-32 px-6 md:px-12 max-w-7xl mx-auto border-b border-[#1B1712]/10"
    >
      {/* Section Header with Drawn Antique Brass Rule on Viewport Enter */}
      <div ref={headingRef} className="max-w-3xl mb-16 md:mb-24">
        <span className="text-[12px] uppercase tracking-[0.22em] text-[#96662C] font-sans-editorial font-medium block mb-3">
          Services Index
        </span>
        <h2
          id="services-heading"
          className="font-serif-editorial italic text-3xl sm:text-4xl md:text-5xl text-[#1B1712] font-normal tracking-tight"
        >
          What we make
        </h2>

        {/* Thin antique-brass rule that draws itself */}
        <div className="relative h-[1px] w-full bg-[#1B1712]/10 mt-6 overflow-hidden">
          <div
            className={`absolute left-0 top-0 bottom-0 bg-[#96662C] transition-all duration-1000 ease-out ${
              ruleVisible ? 'w-32 md:w-48' : 'w-0'
            }`}
          />
        </div>
      </div>

      {/* Editorial Numbered Index (No icon cards) */}
      <div className="divide-y divide-[#1B1712]/10">
        {SERVICES.map((service) => (
          <div
            key={service.number}
            id={`service-${service.number}`}
            className="group py-8 sm:py-10 md:py-14 grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8 items-baseline transition-colors duration-200 hover:bg-[#F7F4EC]/60"
          >
            {/* Large Antique-Brass Serif Numeral */}
            <div className="md:col-span-2">
              <span className="font-serif-editorial text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-[#96662C] font-normal tracking-tight block">
                {service.number}
              </span>
            </div>

            {/* Service Title */}
            <div className="md:col-span-5">
              <h3 className="font-serif-editorial italic text-2xl sm:text-3xl text-[#1B1712] tracking-tight group-hover:text-[#96662C] transition-colors duration-200">
                {service.title}
              </h3>
            </div>

            {/* Service Description */}
            <div className="md:col-span-5">
              <p className="text-sm sm:text-base text-[#1B1712]/75 leading-relaxed font-sans-editorial font-normal">
                {service.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
