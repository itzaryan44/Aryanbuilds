import React, { useEffect, useRef, useState } from 'react';
import { TEAM } from '../data';

export const Team: React.FC = () => {
  const headingRef = useRef<HTMLDivElement>(null);
  const [ruleVisible, setRuleVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRuleVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (headingRef.current) {
      observer.observe(headingRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="team"
      className="py-20 md:py-28 px-6 md:px-12 max-w-7xl mx-auto border-b border-[#1B1712]/10"
    >
      {/* Section Header */}
      <div ref={headingRef} className="max-w-3xl mb-12 md:mb-16">
        <span className="text-[12px] uppercase tracking-[0.22em] text-[#96662C] font-sans-editorial font-medium block mb-3">
          People Behind Advert
        </span>
        <h2
          id="team-heading"
          className="font-serif-editorial italic text-3xl sm:text-4xl md:text-5xl text-[#1B1712] font-normal tracking-tight"
        >
          The studio team
        </h2>

        {/* Thin antique-brass rule that draws itself */}
        <div className="relative h-[1px] w-full bg-[#1B1712]/10 mt-6 overflow-hidden">
          <div
            className={`absolute left-0 top-0 bottom-0 bg-[#96662C] transition-all duration-1000 ease-out ${
              ruleVisible ? 'w-32 md:w-48' : 'w-0'
            }`}
          />
        </div>
      </div>

      {/* Simple Editorial Team Line (No generic profile cards) */}
      <div className="border-t border-[#1B1712]/10 divide-y divide-[#1B1712]/10">
        {TEAM.map((member, index) => (
          <div
            key={member.name}
            id={`team-member-${index}`}
            className="py-6 sm:py-8 flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 sm:gap-8 px-2 sm:px-4 hover:bg-[#1B1712]/[0.015] transition-colors"
          >
            {/* Member Name */}
            <div className="flex items-baseline gap-4">
              <span className="text-xs uppercase tracking-[0.2em] text-[#96662C] font-mono">
                0{index + 1}
              </span>
              <span className="font-serif-editorial italic text-2xl sm:text-3xl text-[#1B1712]">
                {member.name}
              </span>
            </div>

            {/* Member Role */}
            <div>
              <span className="text-sm sm:text-base text-[#1B1712]/75 font-sans-editorial font-normal">
                {member.role}
              </span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
