import React, { useEffect, useRef, useState } from 'react';
import { STUDIO_INFO } from '../data';

interface ContactProps {
  onOpenEnquiry: () => void;
}

export const Contact: React.FC<ContactProps> = ({ onOpenEnquiry }) => {
  const headingRef = useRef<HTMLDivElement>(null);
  const [ruleVisible, setRuleVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRuleVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (headingRef.current) {
      observer.observe(headingRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <footer
      id="contact"
      className="py-24 md:py-36 px-6 md:px-12 max-w-7xl mx-auto"
    >
      {/* Large Editorial Closing Statement */}
      <div ref={headingRef} className="max-w-4xl mb-16 md:mb-24">
        <span className="text-[12px] uppercase tracking-[0.22em] text-[#96662C] font-sans-editorial font-medium block mb-4">
          Begin Production
        </span>
        <h2
          id="contact-closing-statement"
          className="font-serif-editorial italic text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-[#1B1712] font-normal tracking-tight leading-[1.08]"
        >
          Let&apos;s put your shop in front of Giridih.
        </h2>

        {/* Thin antique-brass rule that draws itself */}
        <div className="relative h-[1px] w-full bg-[#1B1712]/10 mt-8 overflow-hidden">
          <div
            className={`absolute left-0 top-0 bottom-0 bg-[#96662C] transition-all duration-1000 ease-out ${
              ruleVisible ? 'w-32 md:w-56' : 'w-0'
            }`}
          />
        </div>
      </div>

      {/* Primary Communication Grid (Text-based links, no generic social icons) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12 md:gap-16 pt-8 border-t border-[#1B1712]/10">
        {/* WhatsApp Channel */}
        <div className="flex flex-col">
          <span className="text-[11px] uppercase tracking-[0.22em] text-[#96662C] font-medium font-sans-editorial mb-3">
            WhatsApp Direct
          </span>
          <a
            href={`https://wa.me/${STUDIO_INFO.whatsappRaw}?text=${encodeURIComponent('Hello Advert Studio, I would like to enquire about video production for my shop.')}`}
            target="_blank"
            rel="noopener noreferrer"
            id="contact-whatsapp-link"
            className="font-serif-editorial italic text-2xl md:text-3xl text-[#1B1712] hover:text-[#96662C] transition-colors leading-tight mb-2"
          >
            {STUDIO_INFO.whatsappNumber}
          </a>
          <span className="text-xs text-[#1B1712]/50 font-sans-editorial">
            Fastest response for local bookings
          </span>
        </div>

        {/* Email Channel */}
        <div className="flex flex-col">
          <span className="text-[11px] uppercase tracking-[0.22em] text-[#96662C] font-medium font-sans-editorial mb-3">
            Direct Mail
          </span>
          <a
            href={`mailto:${STUDIO_INFO.email}`}
            id="contact-email-link"
            className="font-serif-editorial italic text-2xl md:text-3xl text-[#1B1712] hover:text-[#96662C] transition-colors leading-tight mb-2 break-all"
          >
            {STUDIO_INFO.email}
          </a>
          <span className="text-xs text-[#1B1712]/50 font-sans-editorial">
            For proposals & brand briefs
          </span>
        </div>

        {/* Instagram Channel */}
        <div className="flex flex-col">
          <span className="text-[11px] uppercase tracking-[0.22em] text-[#96662C] font-medium font-sans-editorial mb-3">
            Instagram
          </span>
          <a
            href={STUDIO_INFO.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            id="contact-instagram-link"
            className="font-serif-editorial italic text-2xl md:text-3xl text-[#1B1712] hover:text-[#96662C] transition-colors leading-tight mb-2"
          >
            @{STUDIO_INFO.instagramHandle}
          </a>
          <span className="text-xs text-[#1B1712]/50 font-sans-editorial">
            Daily shop reels & behind-the-scenes
          </span>
        </div>

        {/* Physical Studio Location */}
        <div className="flex flex-col">
          <span className="text-[11px] uppercase tracking-[0.22em] text-[#96662C] font-medium font-sans-editorial mb-3">
            Studio Base
          </span>
          <span
            id="contact-location-text"
            className="font-serif-editorial italic text-2xl md:text-3xl text-[#1B1712] leading-tight mb-2"
          >
            {STUDIO_INFO.location}
          </span>
          <span className="text-xs text-[#1B1712]/50 font-sans-editorial">
            Serving shops across Giridih & Jharkhand
          </span>
        </div>
      </div>

      {/* Outlined Enquiry Trigger & Copyright */}
      <div className="mt-20 pt-12 border-t border-[#1B1712]/10 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-6">
          <button
            type="button"
            id="contact-open-form-btn"
            onClick={onOpenEnquiry}
            className="px-6 py-3 border border-[#96662C] text-[#96662C] hover:bg-[#96662C] hover:text-[#F7F4EC] transition-all duration-200 text-xs uppercase tracking-[0.2em] font-medium"
          >
            Open Studio Enquiry Form
          </button>
          <a
            href={`https://wa.me/${STUDIO_INFO.whatsappRaw}`}
            target="_blank"
            rel="noopener noreferrer"
            id="contact-quick-whatsapp-link"
            className="text-xs uppercase tracking-[0.16em] text-[#1B1712]/70 hover:text-[#96662C] transition-colors"
          >
            Chat on WhatsApp ↗
          </a>
        </div>

        <div className="text-xs font-sans-editorial text-[#1B1712]/40 tracking-wider">
          © {new Date().getFullYear()} Advert Studio. All rights reserved. Giridih, Jharkhand.
        </div>
      </div>
    </footer>
  );
};
