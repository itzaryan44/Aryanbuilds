import React, { useEffect, useRef, useState } from 'react';
import { PORTFOLIO } from '../data';
import { PortfolioItem } from '../types';

interface PortfolioProps {
  onSelectReel: (item: PortfolioItem) => void;
}

export const Portfolio: React.FC<PortfolioProps> = ({ onSelectReel }) => {
  const headingRef = useRef<HTMLDivElement>(null);
  const [ruleVisible, setRuleVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRuleVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (headingRef.current) {
      observer.observe(headingRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="work"
      className="py-20 md:py-32 px-6 md:px-12 max-w-7xl mx-auto border-b border-[#1B1712]/10"
    >
      {/* Section Header */}
      <div ref={headingRef} className="max-w-3xl mb-16 md:mb-24">
        <span className="text-[12px] uppercase tracking-[0.22em] text-[#96662C] font-sans-editorial font-medium block mb-3">
          Selected Portfolio
        </span>
        <h2
          id="portfolio-heading"
          className="font-serif-editorial italic text-3xl sm:text-4xl md:text-5xl text-[#1B1712] font-normal tracking-tight"
        >
          Recent client productions
        </h2>

        {/* Thin antique-brass rule that draws itself */}
        <div className="relative h-[1px] w-full bg-[#1B1712]/10 mt-6 overflow-hidden">
          <div
            className={`absolute left-0 top-0 bottom-0 bg-[#96662C] transition-all duration-1000 ease-out ${
              ruleVisible ? 'w-32 md:w-48' : 'w-0'
            }`}
          />
        </div>
      </div>

      {/* Full-width editorial project rows with alternating layout */}
      <div className="flex flex-col divide-y divide-[#1B1712]/10">
        {PORTFOLIO.map((item, index) => {
          const isReversed = index % 2 !== 0;

          return (
            <article
              key={item.id}
              id={`project-row-${item.id}`}
              className="py-16 md:py-24 grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12 items-center"
            >
              {/* Image Container with subtle scale on hover, no shadow, no lift */}
              <div
                className={`lg:col-span-7 overflow-hidden bg-[#1B1712]/5 cursor-pointer ${
                  isReversed ? 'lg:order-2' : 'lg:order-1'
                }`}
                onClick={() => onSelectReel(item)}
              >
                <div className="relative aspect-[16/10] overflow-hidden">
                  <img
                    src={item.imageUrl}
                    alt={`${item.client} showroom & production`}
                    className="w-full h-full object-cover transition-transform duration-700 ease-out hover:scale-[1.02]"
                    loading="lazy"
                  />
                  {/* Subtle editorial label overlay */}
                  <div className="absolute top-4 left-4 z-10 bg-[#F7F4EC]/90 backdrop-blur-sm px-3 py-1 border border-[#1B1712]/10 text-[11px] uppercase tracking-[0.16em] text-[#1B1712]/80 font-medium">
                    {item.category}
                  </div>

                  {/* Reel Play Pill */}
                  <div className="absolute bottom-4 right-4 z-10 bg-[#1B1712]/80 backdrop-blur-sm text-[#F7F4EC] px-3.5 py-1.5 text-[11px] uppercase tracking-[0.16em] flex items-center gap-2 hover:bg-[#96662C] transition-colors">
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#F7F4EC] animate-pulse" />
                    <span>Watch Reel</span>
                  </div>
                </div>
              </div>

              {/* Text / Information Column (Displaying ONLY shop/client name) */}
              <div
                className={`lg:col-span-5 flex flex-col justify-center ${
                  isReversed ? 'lg:order-1' : 'lg:order-2'
                }`}
              >
                {/* Project Index */}
                <div className="text-[12px] uppercase tracking-[0.2em] text-[#96662C] font-sans-editorial font-medium mb-3">
                  Production 0{index + 1}
                </div>

                {/* ONLY the Shop/Client Name */}
                <h3
                  id={`client-name-${item.id}`}
                  className="font-serif-editorial italic text-3xl sm:text-4xl md:text-5xl text-[#1B1712] font-normal tracking-tight mb-4"
                >
                  {item.client}
                </h3>

                {/* Location & Industry context */}
                <div className="flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-[#1B1712]/60 font-sans-editorial mb-8">
                  <span>{item.category}</span>
                  <span>•</span>
                  <span>{item.location}</span>
                </div>

                {/* Actions: Open Instagram Reel directly & Preview Modal */}
                <div className="flex flex-wrap items-center gap-6 text-[13px] uppercase tracking-[0.16em] font-medium font-sans-editorial">
                  <a
                    href={item.reelUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    id={`view-reel-${item.id}`}
                    className="inline-flex items-center gap-2 text-[#96662C] pb-1 border-b border-[#96662C] hover:text-[#1B1712] hover:border-[#1B1712] transition-colors"
                  >
                    <span>Open on Instagram Reel</span>
                    <span>↗</span>
                  </a>

                  <button
                    type="button"
                    id={`preview-reel-${item.id}`}
                    onClick={() => onSelectReel(item)}
                    className="text-[#1B1712]/70 pb-1 border-b border-[#1B1712]/20 hover:text-[#1B1712] hover:border-[#1B1712] transition-colors"
                  >
                    Preview in Reel Player
                  </button>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
};
