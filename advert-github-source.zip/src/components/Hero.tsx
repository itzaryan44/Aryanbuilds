import React from 'react';
import { STUDIO_INFO } from '../data';

interface HeroProps {
  onOpenEnquiry: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenEnquiry }) => {
  return (
    <section
      id="hero-section"
      className="relative pt-16 pb-20 md:pt-24 md:pb-32 px-6 md:px-12 max-w-7xl mx-auto border-b border-[#1B1712]/10"
    >
      <div className="max-w-4xl">
        {/* Editorial Eyebrow / Location & Studio Tag */}
        <div className="flex items-center gap-3 mb-8 text-[12px] uppercase tracking-[0.22em] text-[#96662C] font-sans-editorial font-medium">
          <span className="w-2 h-[1px] bg-[#96662C]" />
          <span>{STUDIO_INFO.location}</span>
          <span className="text-[#1B1712]/30">•</span>
          <span className="text-[#1B1712]/60">Short-Form Content Studio</span>
        </div>

        {/* Headline with Curtain / Mask Wipe Reveal */}
        <div className="curtain-mask my-2">
          <h1
            id="hero-headline"
            className="curtain-reveal font-serif-editorial italic text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.08] text-[#1B1712] font-normal tracking-tight"
          >
            The studio behind Giridih&apos;s most-watched shop ads
          </h1>
        </div>

        {/* Supporting Copy */}
        <div className="mt-8 md:mt-10 max-w-2xl">
          <p
            id="hero-supporting-copy"
            className="text-base sm:text-lg md:text-xl text-[#1B1712]/80 leading-relaxed font-sans-editorial font-normal"
          >
            We produce cinematic short-form video campaigns, regional audio jingles, and showroom coverage for retail, clothing, furniture, automobile dealers, and commercial shops across Giridih and Jharkhand.
          </p>
        </div>

        {/* Two Text-Link CTAs (No filled buttons) */}
        <div className="mt-10 md:mt-12 flex flex-wrap items-center gap-8 text-[13px] uppercase tracking-[0.18em] font-medium font-sans-editorial">
          <a
            href="#work"
            id="hero-cta-work"
            className="group inline-flex items-center gap-2 text-[#1B1712] pb-1 border-b border-[#1B1712] hover:text-[#96662C] hover:border-[#96662C] transition-all duration-200"
          >
            <span>See selected work</span>
            <span className="transition-transform duration-200 group-hover:translate-x-1">→</span>
          </a>

          <a
            href="#pricing"
            id="hero-cta-pricing"
            className="group inline-flex items-center gap-2 text-[#1B1712]/70 pb-1 border-b border-[#1B1712]/30 hover:text-[#96662C] hover:border-[#96662C] transition-all duration-200"
          >
            <span>Explore pricing plans</span>
            <span className="transition-transform duration-200 group-hover:translate-x-1">→</span>
          </a>

          <button
            type="button"
            id="hero-cta-enquire"
            onClick={onOpenEnquiry}
            className="text-[#96662C] pb-1 border-b border-[#96662C]/40 hover:border-[#96662C] transition-all duration-200"
          >
            Direct Enquiry
          </button>
        </div>
      </div>

      {/* Editorial Hairline Accents */}
      <div className="mt-16 md:mt-24 pt-6 border-t border-[#1B1712]/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs font-sans-editorial text-[#1B1712]/50 tracking-wider">
        <span>Production Studio • Commercial & Retail</span>
        <span>Giridih • Jharkhand • India</span>
      </div>
    </section>
  );
};
