import React, { useEffect } from 'react';
import { PortfolioItem } from '../types';

interface ReelPlayerModalProps {
  item: PortfolioItem | null;
  onClose: () => void;
}

export const ReelPlayerModal: React.FC<ReelPlayerModalProps> = ({ item, onClose }) => {
  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  // Lock body scroll
  useEffect(() => {
    if (item) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [item]);

  if (!item) return null;

  return (
    <div
      id="reel-modal-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="reel-modal-client-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#1B1712]/75 backdrop-blur-md animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="reel-modal-card"
        className="relative w-full max-w-sm sm:max-w-md bg-[#F7F4EC] border border-[#1B1712]/15 shadow-2xl p-6 sm:p-8 flex flex-col items-center max-h-[95vh] overflow-y-auto"
      >
        {/* Close Button */}
        <button
          type="button"
          id="close-reel-modal-btn"
          onClick={onClose}
          aria-label="Close reel player"
          className="absolute top-5 right-5 text-xl text-[#1B1712]/60 hover:text-[#1B1712] transition-colors focus:outline-none"
        >
          ✕
        </button>

        {/* Client Tag */}
        <span className="text-[11px] uppercase tracking-[0.22em] text-[#96662C] font-sans-editorial font-medium mb-1 self-start">
          Client Production
        </span>

        {/* ONLY Shop/Client Name */}
        <h3
          id="reel-modal-client-title"
          className="font-serif-editorial italic text-2xl sm:text-3xl text-[#1B1712] font-normal tracking-tight mb-4 self-start"
        >
          {item.client}
        </h3>

        {/* 9:16 Aspect Ratio Frame */}
        <div className="relative w-full aspect-[9/16] max-h-[58vh] bg-[#1B1712] overflow-hidden border border-[#1B1712]/10 mb-6 group">
          <img
            src={item.imageUrl}
            alt={item.client}
            className="w-full h-full object-cover opacity-90 transition-transform duration-700 group-hover:scale-105"
          />

          {/* Reel Overlay Details */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#1B1712]/90 via-transparent to-black/30 p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#F7F4EC] text-xs">
              <span className="font-serif-editorial italic text-base">{item.client}</span>
              <span className="px-2 py-0.5 bg-black/40 text-[10px] uppercase tracking-widest border border-white/20">
                9:16 Reel
              </span>
            </div>

            <div className="space-y-2 text-[#F7F4EC]">
              <div className="flex items-center gap-2 text-[11px] uppercase tracking-wider text-[#96662C]">
                <span>Advert Production</span>
                <span>•</span>
                <span>Giridih</span>
              </div>
              <p className="text-xs text-white/80 line-clamp-2 font-sans-editorial">
                {item.description}
              </p>
            </div>
          </div>
        </div>

        {/* Action Button to Open Reel on Instagram */}
        <div className="w-full space-y-3">
          <a
            href={item.reelUrl}
            target="_blank"
            rel="noopener noreferrer"
            id="watch-on-instagram-btn"
            className="w-full text-center py-3.5 border border-[#96662C] bg-[#96662C] text-[#F7F4EC] hover:bg-[#805523] transition-colors text-xs uppercase tracking-[0.2em] font-medium block"
          >
            Watch Full Reel on Instagram ↗
          </a>

          <button
            type="button"
            onClick={onClose}
            className="w-full text-center py-2 text-xs text-[#1B1712]/60 hover:text-[#1B1712] uppercase tracking-[0.16em]"
          >
            Back to Portfolio
          </button>
        </div>
      </div>
    </div>
  );
};
