import { ClientItem, ServiceItem, PortfolioItem, PricingPlan, TeamMember } from './types';

export const STUDIO_INFO = {
  brand: 'Advert',
  tagline: "The studio behind Giridih's most-watched shop ads",
  location: 'Ghorthamba, Giridih, Jharkhand, India',
  whatsappNumber: '+91 6207255900',
  whatsappRaw: '916207255900',
  email: 'kr.aryan441@gmail.com',
  instagramHandle: 'studio.advert',
  instagramUrl: 'https://www.instagram.com/studio.advert/',
};

export const CLIENT_NAMES: ClientItem[] = [
  { id: '1', name: 'Nawab Collection' },
  { id: '2', name: 'Apna Collection' },
  { id: '3', name: 'Mumbai Plaza' },
  { id: '4', name: 'Boyz Hub' },
  { id: '5', name: 'Azhari Furniture' },
  { id: '6', name: 'Chisti Furniture' },
  { id: '7', name: 'Jharkhand Furniture & Electronics' },
];

export const SERVICES: ServiceItem[] = [
  {
    number: '01',
    title: 'Short-form reels & ads',
    description: 'High-retention cinematic vertical videos tailored for Instagram and WhatsApp status feeds, built specifically to drive footfall to local shops.',
  },
  {
    number: '02',
    title: 'Jingles & voiceovers',
    description: 'Bespoke regional voiceovers and audio signatures crafted in crisp Hindi and regional dialects to establish immediate community recognition.',
  },
  {
    number: '03',
    title: 'Launch & event coverage',
    description: 'Dynamic on-site cinematography for showroom grand openings, festival sale unveilings, and live retail events.',
  },
  {
    number: '04',
    title: 'Shop app on request',
    description: 'Digital catalog and direct mobile ordering presence for businesses ready to transition regular customers into daily digital shoppers.',
  },
];

export const PORTFOLIO: PortfolioItem[] = [
  {
    id: 'apna-collection',
    client: 'Apna Collection',
    category: 'Fashion & Apparel',
    description: 'Short-form commercial reel and collection showcase tailored for local festival shoppers.',
    reelUrl: 'https://www.instagram.com/reel/DZ5AdjhPv0h/?stkn=eGgxMGNyZWpobG1v',
    imageUrl: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=1200&auto=format&fit=crop',
    location: 'Giridih, Jharkhand',
  },
  {
    id: 'jharkhand-furniture',
    client: 'Jharkhand Furniture & Electronics',
    category: 'Furniture & Living',
    description: 'Showroom visual showcase presenting home furnishing collections and consumer appliances.',
    reelUrl: 'https://www.instagram.com/reel/DdOalUrhy8f/?stkn=MW8wM3cxeWR0eDd5Zw==',
    imageUrl: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?q=80&w=1200&auto=format&fit=crop',
    location: 'Giridih, Jharkhand',
  },
  {
    id: 'mumbai-plaza',
    client: 'Mumbai Plaza',
    category: 'Retail & Commercial Plaza',
    description: 'High-energy commercial advertisement capturing customer promotions and store arrivals.',
    reelUrl: 'https://www.instagram.com/reel/DdPEJMWhON3/?stkn=MWRiMnZqam0yNzA0bg==',
    imageUrl: 'https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?q=80&w=1200&auto=format&fit=crop',
    location: 'Giridih, Jharkhand',
  },
];

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'free-trial',
    name: 'Free Trial',
    price: '₹499',
    deliverables: '2 Videos',
    whatsappMessage: 'I’m interested in the Free Trial — ₹499 for 2 videos.',
  },
  {
    id: 'best-quality',
    name: 'Best Quality',
    price: '₹699',
    deliverables: '2 Videos',
    whatsappMessage: 'I’m interested in the Best Quality — ₹699 for 2 videos.',
  },
  {
    id: 'subscription',
    name: 'Subscription',
    price: '₹1,599/month',
    deliverables: '5 Videos per month with full planning',
    isMostRequested: true,
    whatsappMessage: 'I’m interested in the Subscription — ₹1,599/month for 5 videos per month with full planning.',
  },
  {
    id: 'full-marketing',
    name: 'Full Social Media Marketing',
    price: '₹4,999',
    deliverables: 'Full social media marketing',
    whatsappMessage: 'I’m interested in the Full Social Media Marketing — ₹4,999.',
  },
];

export const TEAM: TeamMember[] = [
  {
    name: 'Aryan',
    role: 'Tech & Strategy',
  },
  {
    name: 'Romit',
    role: 'Head Salesman & Cinematographer',
  },
  {
    name: 'Abhijit',
    role: 'Marketing Head & Cinematographer',
  },
];
