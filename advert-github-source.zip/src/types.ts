export interface ClientItem {
  id: string;
  name: string;
}

export interface ServiceItem {
  number: string;
  title: string;
  description: string;
}

export interface PortfolioItem {
  id: string;
  client: string;
  category: string;
  description: string;
  reelUrl: string;
  imageUrl: string;
  location: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  price: string;
  deliverables: string;
  isMostRequested?: boolean;
  whatsappMessage: string;
}

export interface TeamMember {
  name: string;
  role: string;
}

export interface EnquiryData {
  name: string;
  shopName: string;
  phone: string;
  requirement: string;
  message: string;
}
